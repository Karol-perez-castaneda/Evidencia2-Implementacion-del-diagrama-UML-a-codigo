package biblioteca.app;

import biblioteca.modelo.Autor;
import biblioteca.modelo.Libro;
import biblioteca.modelo.LibroDigital;
import biblioteca.modelo.Prestamo;
import biblioteca.servicio.Biblioteca;
import biblioteca.servicio.GestorPrestamos;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Biblioteca biblioteca = new Biblioteca("Biblioteca Universitaria");
    private static final GestorPrestamos gestorPrestamos = new GestorPrestamos();
    private static final Scanner scanner = new Scanner(System.in);
    private static int siguienteNumeroLibro = 1;
    private static int siguienteNumeroPrestamo = 1;

    public static void main(String[] args) {
        cargarDatosIniciales();
        menuPrincipal();
    }

    private static void cargarDatosIniciales() {
        Autor autor1 = new Autor(1, "Gabriel García Márquez");
        Autor autor2 = new Autor(2, "Robert C. Martin");
        biblioteca.registrarAutor(autor1);
        biblioteca.registrarAutor(autor2);

        Libro libro1 = new Libro(siguienteNumeroLibro++, "978-001", "Cien años de soledad", 1967);
        Libro libro2 = new Libro(siguienteNumeroLibro++, "978-002", "Código limpio", 2008);
        LibroDigital libroDigital = new LibroDigital("978-003", "Programación Orientada a Objetos", 2026, 4.5, "PDF");
        libroDigital.setNumeroLibro(siguienteNumeroLibro++);

        autor1.agregarLibro(libro1);
        autor2.agregarLibro(libro2);
        autor2.agregarLibro(libroDigital);

        biblioteca.registrarLibro(libro1);
        biblioteca.registrarLibro(libro2);
        biblioteca.registrarLibro(libroDigital);
    }

    private static void menuPrincipal() {
        boolean salir = false;

        while (!salir) {
            mostrarCabecera();
            System.out.println("1. Registrar libro");
            System.out.println("2. Registrar venta");
            System.out.println("3. Registrar préstamo");
            System.out.println("4. Registrar devolución");
            System.out.println("5. Ver libros");
            System.out.println("6. Ver préstamos");
            System.out.println("7. Salir");
            System.out.println("======================================");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine().trim();

            switch (opcion) {
                case "1":
                    registrarLibro();
                    break;
                case "2":
                    registrarVenta();
                    break;
                case "3":
                    registrarPrestamo();
                    break;
                case "4":
                    registrarDevolucion();
                    break;
                case "5":
                    mostrarLibros();
                    break;
                case "6":
                    mostrarPrestamos();
                    break;
                case "7":
                    salir = true;
                    System.out.println("\nHasta luego.");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    pausar();
            }
        }
    }

    private static void registrarLibro() {
        System.out.println("\n=== REGISTRAR LIBRO ===");
        System.out.print("Título: ");
        String titulo = scanner.nextLine().trim();

        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();

        System.out.print("Año de publicación: ");
        int anio = leerEntero();

        Libro libro = new Libro(siguienteNumeroLibro++, isbn, titulo, anio);
        biblioteca.registrarLibro(libro);

        System.out.println("Libro registrado correctamente con número: " + libro.getNumeroLibro());
        pausar();
    }

    private static void registrarVenta() {
        System.out.println("\n=== REGISTRAR VENTA ===");
        Libro libro = seleccionarLibro();
        if (libro == null) {
            return;
        }

        if (libro.estaVendido()) {
            System.out.println("Este libro ya fue vendido.");
            pausar();
            return;
        }

        System.out.print("Nombre del comprador: ");
        String comprador = scanner.nextLine().trim();

        System.out.print("Fecha de venta (yyyy-MM-dd): ");
        LocalDate fechaVenta = leerFecha();

        libro.vender(comprador, fechaVenta);
        System.out.println("Venta registrada correctamente.");
        System.out.println("Libro: " + libro.getTitulo());
        System.out.println("Comprador: " + libro.getAdquiriente());
        System.out.println("Fecha venta: " + libro.getFechaVenta());
        pausar();
    }

    private static void registrarPrestamo() {
        System.out.println("\n=== REGISTRAR PRÉSTAMO ===");
        Libro libro = seleccionarLibro();
        if (libro == null) {
            return;
        }

        if (libro.estaVendido()) {
            System.out.println("No se puede prestar un libro vendido.");
            pausar();
            return;
        }

        if (!libro.estaDisponible()) {
            System.out.println("El libro no está disponible para préstamo.");
            pausar();
            return;
        }

        System.out.print("Nombre del cliente: ");
        String cliente = scanner.nextLine().trim();

        System.out.print("Fecha de entrega (yyyy-MM-dd): ");
        LocalDate fechaPrestamo = leerFecha();

        Prestamo prestamo = new Prestamo(siguienteNumeroPrestamo++, libro, cliente, fechaPrestamo);
        gestorPrestamos.registrarPrestamo(prestamo);
        libro.prestar();

        System.out.println("Préstamo registrado correctamente.");
        System.out.println("N° préstamo: " + prestamo.getNumeroPrestamo());
        System.out.println("Libro: " + prestamo.getLibro().getTitulo());
        System.out.println("Cliente: " + prestamo.getNombreCliente());
        System.out.println("Fecha entrega: " + prestamo.getFechaPrestamo());
        pausar();
    }

    private static void registrarDevolucion() {
        System.out.println("\n=== REGISTRAR DEVOLUCIÓN ===");
        List<Prestamo> activos = gestorPrestamos.obtenerPrestamosActivos();

        if (activos.isEmpty()) {
            System.out.println("No hay préstamos activos.");
            pausar();
            return;
        }

        for (Prestamo prestamo : activos) {
            System.out.println(prestamo.getNumeroPrestamo() + " - " + prestamo.getLibro().getTitulo() + " - Cliente: " + prestamo.getNombreCliente());
        }

        System.out.print("Ingrese el número del préstamo a devolver: ");
        int numeroPrestamo = leerEntero();

        Prestamo prestamo = null;
        for (Prestamo p : activos) {
            if (p.getNumeroPrestamo() == numeroPrestamo) {
                prestamo = p;
                break;
            }
        }

        if (prestamo == null) {
            System.out.println("Número de préstamo no encontrado.");
            pausar();
            return;
        }

        System.out.print("Fecha de devolución (yyyy-MM-dd): ");
        LocalDate fechaDevolucion = leerFecha();

        gestorPrestamos.devolver(prestamo, fechaDevolucion);
        System.out.println("Devolución registrada correctamente.");
        System.out.println("Libro: " + prestamo.getLibro().getTitulo());
        System.out.println("Fecha devolución: " + prestamo.getFechaDevolucion());
        pausar();
    }

    private static void mostrarLibros() {
        System.out.println("\n=== LIBROS ===");
        List<Libro> libros = biblioteca.getLibros();
        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
        } else {
            for (Libro libro : libros) {
                System.out.println("N° " + libro.getNumeroLibro() + " | " + libro.getTitulo() + " | ISBN: " + libro.getIsbn() + " | Estado: " + libro.getEstado());
                if (libro.estaVendido()) {
                    System.out.println("   Comprador: " + libro.getAdquiriente() + " | Fecha venta: " + libro.getFechaVenta());
                }
            }
        }
        pausar();
    }

    private static void mostrarPrestamos() {
        System.out.println("\n=== PRÉSTAMOS ===");
        List<Prestamo> prestamos = gestorPrestamos.getPrestamos();
        if (prestamos.isEmpty()) {
            System.out.println("No hay préstamos registrados.");
        } else {
            for (Prestamo prestamo : prestamos) {
                System.out.println("N° préstamo: " + prestamo.getNumeroPrestamo()
                        + " | Libro: " + prestamo.getLibro().getTitulo()
                        + " | Cliente: " + prestamo.getNombreCliente()
                        + " | Inicio: " + prestamo.getFechaPrestamo()
                        + " | Estado: " + prestamo.getEstado());
                if (prestamo.estaDevuelto()) {
                    System.out.println("   Fecha devolución: " + prestamo.getFechaDevolucion());
                }
            }
        }
        pausar();
    }

    private static Libro seleccionarLibro() {
        List<Libro> libros = biblioteca.getLibros();
        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
            pausar();
            return null;
        }

        System.out.println("Libros disponibles:");
        for (Libro libro : libros) {
            System.out.println("N° " + libro.getNumeroLibro() + " - " + libro.getTitulo() + " | Estado: " + libro.getEstado());
        }

        System.out.print("Ingrese el número del libro: ");
        int numeroLibro = leerEntero();

        for (Libro libro : libros) {
            if (libro.getNumeroLibro() == numeroLibro) {
                return libro;
            }
        }

        System.out.println("Número de libro no encontrado.");
        pausar();
        return null;
    }

    private static int leerEntero() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Valor inválido. Intente nuevamente: ");
            }
        }
    }

    private static LocalDate leerFecha() {
        while (true) {
            String entrada = scanner.nextLine().trim();
            try {
                return LocalDate.parse(entrada);
            } catch (DateTimeParseException e) {
                System.out.print("Formato inválido. Use yyyy-MM-dd: ");
            }
        }
    }

    private static void pausar() {
        System.out.println("\nPresione Enter para continuar...");
        scanner.nextLine();
    }

    private static void mostrarCabecera() {
        System.out.println("\n======================================");
        System.out.println("       SISTEMA DE BIBLIOTECA");
        System.out.println("======================================");
    }
}
