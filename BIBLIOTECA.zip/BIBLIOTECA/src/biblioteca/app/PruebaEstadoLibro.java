package biblioteca.app;

import biblioteca.modelo.Libro;
import biblioteca.modelo.Prestamo;

import java.time.LocalDate;

public class PruebaEstadoLibro {
    public static void main(String[] args) {
        Libro libro = new Libro(101, "978-001", "Cien años de soledad", 1967);
        libro.vender("Ana López", LocalDate.of(2026, 9, 1));
        Prestamo prestamo = new Prestamo(5001, libro, "Carlos Ruiz", LocalDate.of(2026, 9, 5));
        prestamo.registrarDevolucion(LocalDate.of(2026, 9, 12));

        System.out.println("Numero libro: " + libro.getNumeroLibro());
        System.out.println("Vendido: " + libro.estaVendido());
        System.out.println("Comprador: " + libro.getAdquiriente());
        System.out.println("Prestamo activo: " + prestamo.estaActivo());
        System.out.println("Fecha entrega: " + prestamo.getFechaPrestamo());
        System.out.println("Fecha devolucion: " + prestamo.getFechaDevolucion());
    }
}
