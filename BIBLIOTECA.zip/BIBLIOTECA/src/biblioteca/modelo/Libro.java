package biblioteca.modelo;

import java.time.LocalDate;

public class Libro {

    private int numeroLibro;
    private String isbn;
    private String titulo;
    private int anioPublicacion;
    private boolean disponible;
    private boolean vendido;
    private String adquiriente;
    private LocalDate fechaVenta;

    public Libro(String isbn, String titulo, int anioPublicacion) {
        this(0, isbn, titulo, anioPublicacion);
    }

    public Libro(int numeroLibro, String isbn, String titulo, int anioPublicacion) {
        this.numeroLibro = numeroLibro;
        this.isbn = isbn;
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
        this.disponible = true;
        this.vendido = false;
        this.adquiriente = null;
        this.fechaVenta = null;
    }

    public int getNumeroLibro() {
        return numeroLibro;
    }

    public void setNumeroLibro(int numeroLibro) {
        this.numeroLibro = numeroLibro;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public boolean estaDisponible() {
        return disponible;
    }

    public void prestar() {
        if (!disponible) {
            throw new IllegalStateException("El libro no está disponible.");
        }
        disponible = false;
    }

    public void devolver() {
        disponible = true;
    }

    public boolean estaVendido() {
        return vendido;
    }

    public String getAdquiriente() {
        return adquiriente;
    }

    public LocalDate getFechaVenta() {
        return fechaVenta;
    }

    public void vender(String adquiriente, LocalDate fechaVenta) {
        if (adquiriente == null || adquiriente.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del comprador es obligatorio.");
        }
        if (fechaVenta == null) {
            throw new IllegalArgumentException("La fecha de venta es obligatoria.");
        }

        this.vendido = true;
        this.adquiriente = adquiriente;
        this.fechaVenta = fechaVenta;
        this.disponible = false;
    }

    public String getEstado() {
        if (vendido) {
            return "Vendido";
        }
        if (disponible) {
            return "Disponible";
        }
        return "En préstamo";
    }

    public String getDescripcion() {
        return titulo + " (" + anioPublicacion + ")";
    }

    public void actualizarInformacion(String titulo) {
        this.titulo = titulo;
    }

    public void actualizarInformacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    @Override
    public String toString() {
        return "Libro{" +
                "numeroLibro=" + numeroLibro +
                ", isbn='" + isbn + '\'' +
                ", titulo='" + titulo + '\'' +
                ", anioPublicacion=" + anioPublicacion +
                ", disponible=" + disponible +
                ", vendido=" + vendido +
                ", adquiriente='" + adquiriente + '\'' +
                ", fechaVenta=" + fechaVenta +
                '}';
    }
}
