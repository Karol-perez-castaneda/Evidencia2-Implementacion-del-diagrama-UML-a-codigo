package biblioteca.modelo;

public class LibroDigital extends Libro {

    private double tamanoMB;
    private String formato;

    public LibroDigital(String isbn, String titulo, int anioPublicacion, double tamanoMB, String formato) {
        super(isbn, titulo, anioPublicacion);
        this.tamanoMB = tamanoMB;
        this.formato = formato;
    }

    public double getTamanoMB() {
        return tamanoMB;
    }

    public void setTamanoMB(double tamanoMB) {
        this.tamanoMB = tamanoMB;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    @Override
    public String getDescripcion() {
        return getTitulo() + " - formato digital: " + formato + " - " + tamanoMB + " MB";
    }
}
