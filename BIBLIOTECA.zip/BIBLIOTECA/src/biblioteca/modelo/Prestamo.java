package biblioteca.modelo;

import java.time.LocalDate;

public class Prestamo {

    private final int numeroPrestamo;
    private final Libro libro;
    private final String nombreCliente;
    private final LocalDate fechaPrestamo;
    private LocalDate fechaDevolucion;

    public Prestamo(Libro libro, LocalDate fechaPrestamo) {
        this(0, libro, "Sin cliente asignado", fechaPrestamo);
    }

    public Prestamo(int numeroPrestamo, Libro libro, String nombreCliente, LocalDate fechaPrestamo) {
        if (libro == null) {
            throw new IllegalArgumentException("El libro es obligatorio.");
        }

        if (fechaPrestamo == null) {
            throw new IllegalArgumentException("La fecha del préstamo es obligatoria.");
        }

        if (nombreCliente == null || nombreCliente.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del cliente es obligatorio.");
        }

        this.numeroPrestamo = numeroPrestamo;
        this.libro = libro;
        this.nombreCliente = nombreCliente;
        this.fechaPrestamo = fechaPrestamo;
    }

    public int getNumeroPrestamo() {
        return numeroPrestamo;
    }

    public Libro getLibro() {
        return libro;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }

    public boolean estaActivo() {
        return fechaDevolucion == null;
    }

    public boolean estaDevuelto() {
        return !estaActivo();
    }

    public String getEstado() {
        return estaActivo() ? "En préstamo" : "Devuelto";
    }

    public void registrarDevolucion(LocalDate fechaDevolucion) {
        if (fechaDevolucion == null) {
            throw new IllegalArgumentException("La fecha de devolución es obligatoria.");
        }

        if (fechaDevolucion.isBefore(fechaPrestamo)) {
            throw new IllegalArgumentException("La devolución no puede ser anterior al préstamo.");
        }

        this.fechaDevolucion = fechaDevolucion;
    }
}
