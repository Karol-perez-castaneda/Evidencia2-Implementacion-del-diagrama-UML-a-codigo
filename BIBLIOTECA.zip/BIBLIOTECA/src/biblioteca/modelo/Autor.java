package biblioteca.modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Autor {

    private int id;
    private String nombre;
    private final List<Libro> libros;

    public Autor(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.libros = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Libro> getLibros() {
        return Collections.unmodifiableList(libros);
    }

    public void agregarLibro(Libro libro) {
        if (libro == null) {
            throw new IllegalArgumentException("El libro no puede ser nulo.");
        }

        if (!libros.contains(libro)) {
            libros.add(libro);
        }
    }

    public void eliminarLibro(Libro libro) {
        libros.remove(libro);
    }
}
