package biblioteca.servicio;

import biblioteca.modelo.Autor;
import biblioteca.modelo.Libro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Biblioteca {

    private final String nombre;
    private final List<Libro> libros;
    private final List<Autor> autores;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.libros = new ArrayList<>();
        this.autores = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public List<Libro> getLibros() {
        return Collections.unmodifiableList(libros);
    }

    public List<Autor> getAutores() {
        return Collections.unmodifiableList(autores);
    }

    public void registrarLibro(Libro libro) {
        if (libro == null) {
            throw new IllegalArgumentException("El libro no puede ser nulo.");
        }

        if (!libros.contains(libro)) {
            libros.add(libro);
        }
    }

    public void registrarAutor(Autor autor) {
        if (autor == null) {
            throw new IllegalArgumentException("El autor no puede ser nulo.");
        }

        if (!autores.contains(autor)) {
            autores.add(autor);
        }
    }

    public Libro buscarLibro(String isbn) {
        for (Libro libro : libros) {
            if (libro.getIsbn().equalsIgnoreCase(isbn)) {
                return libro;
            }
        }
        return null;
    }

    public List<Libro> buscarPorTitulo(String titulo) {
        List<Libro> resultados = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.getTitulo().toLowerCase().contains(titulo.toLowerCase())) {
                resultados.add(libro);
            }
        }
        return resultados;
    }

    public List<Libro> obtenerLibrosDisponibles() {
        List<Libro> disponibles = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.estaDisponible()) {
                disponibles.add(libro);
            }
        }
        return disponibles;
    }

    public boolean eliminarLibro(Libro libro) {
        return libros.remove(libro);
    }

    public int cantidadLibros() {
        return libros.size();
    }

    public int cantidadAutores() {
        return autores.size();
    }

    @Override
    public String toString() {
        return "Biblioteca{" +
                "nombre='" + nombre + '\'' +
                ", libros=" + libros.size() +
                ", autores=" + autores.size() +
                '}';
    }
}
