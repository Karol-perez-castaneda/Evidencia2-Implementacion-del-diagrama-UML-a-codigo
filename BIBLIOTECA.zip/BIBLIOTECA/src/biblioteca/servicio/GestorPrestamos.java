package biblioteca.servicio;

import biblioteca.modelo.Libro;
import biblioteca.modelo.Prestamo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GestorPrestamos {

    private final List<Prestamo> prestamos;

    public GestorPrestamos() {
        this.prestamos = new ArrayList<>();
    }

    public Prestamo prestar(Libro libro) {
        return prestar(libro, LocalDate.now());
    }

    public Prestamo prestar(Libro libro, LocalDate fechaPrestamo) {
        if (libro == null) {
            throw new IllegalArgumentException("El libro no puede ser nulo.");
        }

        if (!libro.estaDisponible()) {
            throw new IllegalStateException("El libro no está disponible.");
        }

        libro.prestar();
        Prestamo prestamo = new Prestamo(libro, fechaPrestamo);
        prestamos.add(prestamo);

        return prestamo;
    }

    public void devolver(Prestamo prestamo, LocalDate fechaDevolucion) {
        if (prestamo == null) {
            throw new IllegalArgumentException("El préstamo no puede ser nulo.");
        }

        if (!prestamo.estaActivo()) {
            throw new IllegalStateException("El préstamo ya fue cerrado.");
        }

        prestamo.registrarDevolucion(fechaDevolucion);
        prestamo.getLibro().devolver();
    }

    public void registrarPrestamo(Prestamo prestamo) {
        if (prestamo == null) {
            throw new IllegalArgumentException("El préstamo no puede ser nulo.");
        }

        prestamos.add(prestamo);
    }

    public List<Prestamo> getPrestamos() {
        return Collections.unmodifiableList(prestamos);
    }

    public List<Prestamo> obtenerPrestamosActivos() {
        List<Prestamo> activos = new ArrayList<>();
        for (Prestamo prestamo : prestamos) {
            if (prestamo.estaActivo()) {
                activos.add(prestamo);
            }
        }
        return activos;
    }

    public Prestamo buscarPrestamoActivo(Libro libro) {
        for (Prestamo prestamo : prestamos) {
            if (prestamo.estaActivo() && prestamo.getLibro() == libro) {
                return prestamo;
            }
        }
        return null;
    }

    public int cantidadPrestamos() {
        return prestamos.size();
    }

    public int cantidadPrestamosActivos() {
        return obtenerPrestamosActivos().size();
    }
}
