# Sistema de Biblioteca

## Descripción

Sistema desarrollado en Java para representar las principales
operaciones de una biblioteca mediante programación orientada a objetos.

## Objetivo

Implementar el modelo UML diseñado en la Actividad 1,
aplicando encapsulamiento, herencia, polimorfismo,
sobrecarga, sobrescritura y principios SOLID.

## Tecnologías

- Java
- JDK 17
- Git
- GitHub

## Estructura

src/
└── biblioteca/
    ├── modelo/
    ├── servicio/
    └── app/

## Principios POO

### Encapsulamiento
Los atributos de las entidades se mantienen privados...

### Herencia
LibroDigital extiende Libro...

### Polimorfismo
Se utiliza una colección de tipo List<Libro>...

### Sobrecarga
...

### Sobrescritura
...

## Principios SOLID

### SRP
...

### OCP
...

### LSP
...

## Ejecución

Ejecutar la clase Main.

## Integrantes

- Integrante 1
- Integrante 2
- Integrante 3

## Repositorio

[Enlace al repositorio]

## Video

[Enlace al video de sustentación]